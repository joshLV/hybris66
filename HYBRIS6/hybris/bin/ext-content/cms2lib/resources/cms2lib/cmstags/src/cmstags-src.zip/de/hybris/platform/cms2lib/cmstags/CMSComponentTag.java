/*
 * [y] hybris Platform
 *
 * Copyright (c) 2017 SAP SE or an SAP affiliate company. All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package de.hybris.platform.cms2lib.cmstags;

import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.misc.CMSFilter;
import de.hybris.platform.cms2.model.contents.components.AbstractCMSComponentModel;
import de.hybris.platform.cms2.model.contents.components.SimpleCMSComponentModel;
import de.hybris.platform.cms2.model.contents.containers.AbstractCMSComponentContainerModel;
import de.hybris.platform.cms2.model.contents.contentslot.ContentSlotModel;
import de.hybris.platform.cms2.model.preview.CMSPreviewTicketModel;
import de.hybris.platform.cms2.servicelayer.data.CMSDataFactory;
import de.hybris.platform.cms2.servicelayer.data.RestrictionData;
import de.hybris.platform.cms2.servicelayer.services.CMSComponentService;
import de.hybris.platform.cms2.servicelayer.services.CMSPreviewService;
import de.hybris.platform.cms2.servicelayer.services.CMSRestrictionService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


public class CMSComponentTag extends TagSupport
{
	private static final long serialVersionUID = 1334123496915519595L;

	private static final Logger LOG = Logger.getLogger(CMSComponentTag.class.getName());

	protected static final String INIT_LE_JS = "initLiveEdit";
	protected static final String DEFAULT_CONTROLLER = "DefaultCMSComponentController";

	private String uid;
	private AbstractCMSComponentModel component;
	private boolean evaluateRestriction;

	/*
	 * Suppress sonar warning (squid:S1699 | Constructors should only call non-overridable methods) : Legacy code
	 */
	@SuppressWarnings("squid:S1699")
	public CMSComponentTag()
	{
		super();
		init();
	}

	@Override
	public void release()
	{
		super.release();
		init();
	}

	protected void init()
	{
		uid = null;
	}

	protected ServletContext getServletContext()
	{
		return pageContext.getServletContext();
	}

	protected Collection<SimpleCMSComponentModel> getComponents(final WebApplicationContext appContext,
			final HttpServletRequest request) throws CMSItemNotFoundException
	{
		final List<SimpleCMSComponentModel> ret = new ArrayList<SimpleCMSComponentModel>();
		AbstractCMSComponentModel component = null;
		final CMSComponentService service = (CMSComponentService) appContext.getBean("cmsComponentService");
		final CMSRestrictionService cmsRestrictionService = (CMSRestrictionService) appContext.getBean("cmsRestrictionService");
		final CMSDataFactory restrictionDataFactory = (CMSDataFactory) appContext.getBean("cmsDataFactory");
		final RestrictionData restrictionData = populate(request, restrictionDataFactory);
		final boolean previewEnabled = isPreviewEnabled();

		if (this.component != null)
		{
			component = this.component;
		}
		else if (StringUtils.isNotEmpty(uid))
		{
			component = service.getAbstractCMSComponent(uid);
		}
		else
		{
			throw new CMSItemNotFoundException(
					"No component found for uid [" + uid + "] or component [" + component + "] parameter");
		}

		final boolean allowed = isAllowed(component, restrictionData, cmsRestrictionService, previewEnabled);
		if (allowed)
		{
			if (component.isContainer())
			{
				final AbstractCMSComponentContainerModel container = (AbstractCMSComponentContainerModel) component;
				for (final SimpleCMSComponentModel innerComponent : container.getCurrentCMSComponents())
				{
					if (isAllowed(innerComponent, restrictionData, cmsRestrictionService, previewEnabled))
					{
						ret.add(innerComponent);
					}
				}
			}
			else
			{
				ret.add((SimpleCMSComponentModel) component);
			}
		}
		return ret;
	}

	/**
	 * Checks whether component should be displayed.<br/>
	 * <p/>
	 * Note: Computation takes into account:
	 * <ul>
	 * <li>Checks whether component is visible</li>
	 * <li>If component is restricted checks whether we should display it</li>
	 * </ul>
	 */
	protected boolean isAllowed(final AbstractCMSComponentModel component, final RestrictionData restrictionData,
			final CMSRestrictionService cmsRestrictionService, final boolean previewEnabled)
	{
		boolean allowed = true;
		if (Boolean.FALSE.equals(component.getVisible()))
		{
			allowed = false;
		}
		else if (component.isRestricted() && !previewEnabled && evaluateRestriction)
		{
			allowed = cmsRestrictionService.evaluateCMSComponent(component, restrictionData);
		}
		return allowed;
	}


	protected boolean isPreviewEnabled()
	{
		boolean previewEnabled = false;

		final String ticketId = pageContext.getRequest().getParameter(CMSFilter.PREVIEW_TICKET_ID_PARAM);
		if (StringUtils.isNotBlank(ticketId))
		{
			final WebApplicationContext appContext = WebApplicationContextUtils
					.getRequiredWebApplicationContext(pageContext.getServletContext());
			final CMSPreviewService service = (CMSPreviewService) appContext.getBean("cmsPreviewService");
			final CMSPreviewTicketModel previewTicket = service.getPreviewTicket(ticketId);
			if (previewTicket == null)
			{
				LOG.warn("No preview ticket found with id '" + ticketId + "'.");
			}
			else
			{
				previewEnabled = Boolean.FALSE.equals(previewTicket.getPreviewData().getEditMode());
			}
		}
		else if (LOG.isDebugEnabled())
		{
			LOG.debug("Could not determine preview edit status. Reason: No preview ticket ID supplied.");
		}
		return previewEnabled;
	}


	protected boolean isLiveEdit()
	{
		boolean liveEdit = false;

		final String ticketId = pageContext.getRequest().getParameter(CMSFilter.PREVIEW_TICKET_ID_PARAM);
		if (StringUtils.isNotBlank(ticketId))
		{
			final WebApplicationContext appContext = WebApplicationContextUtils
					.getRequiredWebApplicationContext(getServletContext());
			final CMSPreviewService service = (CMSPreviewService) appContext.getBean("cmsPreviewService");
			final CMSPreviewTicketModel previewTicket = service.getPreviewTicket(ticketId);
			if (previewTicket == null)
			{
				LOG.warn("No preview ticket found with id '" + ticketId + "'.");
			}
			else
			{
				liveEdit = Boolean.TRUE.equals(previewTicket.getPreviewData().getLiveEdit());
			}
		}
		else
		{
			if (LOG.isDebugEnabled())
			{
				LOG.debug("Could not determine live edit status. Reason: No preview ticket ID supplied.");
			}
		}

		return liveEdit;
	}

	@Override
	public int doStartTag() throws JspException
	{
		final WebApplicationContext appContext = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
		final HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();

		final boolean liveEdit = isLiveEdit();
		if (liveEdit)
		{
			final String init = (String) request.getAttribute(INIT_LE_JS);
			if (StringUtils.isEmpty(init))
			{
				initLiveEditJS(request);
				request.setAttribute(INIT_LE_JS, "true");
			}
		}
		try
		{
			final ContentSlotModel contentSlot = (ContentSlotModel) request.getAttribute("contentSlot");
			final String prefix = contentSlot == null ? "ceid_" : "ceid_" + contentSlot.getUid() + "___";
			for (final SimpleCMSComponentModel element : getComponents(appContext, request))
			{
				final String id = prefix + element.getUid();
				if (liveEdit)
				{
					pageContext.getOut().write("<!-- Start of liveEdit [" + id + "] -->");
					pageContext.getOut().write("<div id=\"" + id + "\">");
				}
				pageContext.setAttribute("componentUid", element.getUid(), PageContext.REQUEST_SCOPE);
				final String code = element.getTypeCode();
				String controllerName = code + "Controller";
				if (!appContext.containsBean(controllerName))
				{
					LOG.debug("No controller defined for ContentElement [" + code + "]. Using default Controller");
					controllerName = DEFAULT_CONTROLLER;
				}
				pageContext.include("/view/" + controllerName);
				if (liveEdit)
				{
					pageContext.getOut().write("</div>");
					pageContext.getOut().write("<!-- End of liveEdit [" + id + "] -->");
				}
			}
		}
		catch (final Exception e)
		{
			LOG.warn("Error processing tag", e);
		}
		return SKIP_BODY;
	}

	protected void initLiveEditJS(final HttpServletRequest request)
	{
		final JspWriter out = pageContext.getOut();

		try
		{
			out.write(
					"<link rel=\"stylesheet\" type=\"text/css\" href=\"" + request.getContextPath() + "/stylesheets/liveEdit.css\"/>");
			out.write("<script type=\"text/javascript\" src=\"" + request.getContextPath() + "/js/liveedit.js\"></script>");
		}
		catch (final IOException e)
		{
			LOG.warn("Could not write initial liveEdit JavaScript", e);
		}
	}

	@Override
	public int doEndTag() throws JspException
	{
		return EVAL_PAGE;
	}

	public void setUid(final String uid)
	{
		this.uid = uid;
	}

	public void setComponent(final AbstractCMSComponentModel component)
	{
		this.component = component;
	}

	public void setEvaluateRestriction(final boolean evaluateRestriction)
	{
		this.evaluateRestriction = evaluateRestriction;
	}

	/**
	 * Wrapped all information fetched from current HTTP request
	 * <p/>
	 *
	 * @param request
	 *           current HTTP request
	 * @return all gather information wrapped to {@link RestrictionData} object
	 */
	/*
	 * Suppress sonar warning (squid:S2583 | Conditions should not unconditionally evaluate to "TRUE" or to "FALSE") :
	 * The condition is does not always evaluate to "TRUE" or to "FALSE".
	 */
	@SuppressWarnings("squid:S2583")
	protected RestrictionData populate(final HttpServletRequest request, final CMSDataFactory cmsDataFactory)
	{
		final Object catalog = request.getAttribute("catalogId");
		final Object category = request.getAttribute("currentCategoryCode");
		final Object product = request.getAttribute("currentProductCode");

		final String catalogId = (catalog instanceof String) && Objects.nonNull(catalog) ? catalog.toString() : "";
		final String categoryCode = (category instanceof String) && Objects.nonNull(category) ? category.toString() : "";
		final String productCode = (product instanceof String) && Objects.nonNull(product) ? product.toString() : "";
		return cmsDataFactory.createRestrictionData(categoryCode, productCode, catalogId);
	}

}
